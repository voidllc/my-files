const trackId = new URLSearchParams(location.search).get("id") || "";
const cart = JSON.parse(localStorage.getItem("mrHawkerCart") || "[]");
document.querySelectorAll("#cartCount").forEach(el => el.textContent = cart.reduce((total, item) => total + Number(item.quantity || 0), 0));

const statusSteps = [
  ["pending", "Pending", "Your order has been received."],
  ["packaging", "Packaging", "Your order is being prepared."],
  ["ready_to_shipping", "Ready to Shipping", "Your order is ready for dispatch."],
  ["shipped_to_rider", "Shipped to Rider", "Your order has been handed to the delivery rider."],
  ["completed", "Completed", "Your order has been delivered successfully."]
];

const esc = value => String(value ?? "").replace(/[&<>"']/g, m => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
}[m]));

function normalizeStatus(value) {
  const v = String(value || "pending").toLowerCase().trim();
  const aliases = {
    "ready to shipping": "ready_to_shipping",
    "ready_to_ship": "ready_to_shipping",
    "ready-to-shipping": "ready_to_shipping",
    "shipped": "shipped_to_rider",
    "shipped to rider": "shipped_to_rider",
    "delivered": "completed",
    "complete": "completed"
  };
  return aliases[v] || v;
}

function parseDetails(value) {
  if (!value) return {};
  if (typeof value === "object") return value;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function firstValue(data, keys) {
  for (const key of keys) {
    if (data && data[key] !== undefined && data[key] !== null && String(data[key]).trim() !== "") {
      return data[key];
    }
  }
  return "";
}

function renderDetail(label, value, href = "") {
  if (!value) return "";
  const content = href
    ? `<a href="${esc(href)}">${esc(value)}</a>`
    : `<strong>${esc(value)}</strong>`;
  return `<div><span>${esc(label)}</span>${content}</div>`;
}

function renderOrder(order) {
  const status = normalizeStatus(order.delivery_status);
  const data = parseDetails(order.delivery_data || order.delivery_status_data);
  const box = document.getElementById("trackResult");

  if (status === "rejected") {
    const reason = firstValue(data, ["reason", "rejection_reason", "message"]) || "This order was rejected by the shop.";
    const note = firstValue(data, ["note", "details", "description"]);
    box.innerHTML = `
      <div class="track-special-card rejected-card">
        <span class="eyebrow">ORDER REJECTED</span>
        <h2>Payment / Order Rejected</h2>
        <p>${esc(reason)}</p>
        ${note ? `<small>${esc(note)}</small>` : ""}
      </div>`;
    return;
  }

  if (status === "shipped_to_rider") {
    // The new delivery_data JSON is flat, for example:
    // { rider_name, company_name, vehicle, vehicle_number, rider_phone, note }
    // Nested { rider: {...} } data is also supported for backward compatibility.
    const rider = data.rider && typeof data.rider === "object" ? data.rider : data;
    const riderName = firstValue(rider, ["rider_name", "name", "rider"]);
    const company = firstValue(rider, ["company_name", "company", "delivery_company"]);
    const vehicle = firstValue(rider, ["vehicle", "vehicle_type"]);
    const vehicleNumber = firstValue(rider, ["vehicle_number", "vehicle_no", "number_plate", "plate_number", "car_number", "bike_number"]);
    const riderPhone = firstValue(rider, ["rider_phone", "phone", "contact_number", "contact_phone"]);
    const riderId = firstValue(rider, ["rider_id", "id"]);
    const note = firstValue(rider, ["note", "details"]);

    box.innerHTML = `
      <div class="track-special-card rider-card">
        <span class="eyebrow">OUT FOR DELIVERY</span>
        <h2>Shipped to Rider</h2>
        <p>Your order has been handed to the delivery rider.</p>
        <div class="rider-grid">
          ${renderDetail("Rider Name", riderName)}
          ${renderDetail("Company", company)}
          ${renderDetail("Vehicle", vehicle)}
          ${renderDetail("Vehicle Number", vehicleNumber)}
          ${renderDetail("Rider Contact", riderPhone, riderPhone ? `tel:${String(riderPhone).replace(/[^+\d]/g, "")}` : "")}
          ${renderDetail("Rider ID", riderId)}
          ${renderDetail("Note", note)}
        </div>
      </div>`;
  }

  const index = Math.max(0, statusSteps.findIndex(step => step[0] === status));
  const current = statusSteps[index] || statusSteps[0];

  box.innerHTML = `
    <div class="track-summary">
      <span class="eyebrow">DELIVERY TRACKING</span>
      <h1>${esc(order.delivery_track_id)}</h1>
      <p>${esc(current[2])}</p>
      <span class="track-status">${esc(current[1])}</span>
    </div>
    <div class="track-timeline">
      ${statusSteps.map((step, i) => `
        <div class="track-step ${i <= index ? "done" : ""} ${i === index ? "current" : ""}">
          <span class="track-dot"></span>
          <div><strong>${esc(step[1])}</strong><small>${esc(step[2])}</small></div>
        </div>`).join("")}
    </div>
    <div class="track-meta">
      <div><span>Order date</span><strong>${esc(order.order_date || "—")}</strong></div>
      <div><span>Expected delivery</span><strong>${esc(order.delivery_date || "Pending update")}</strong></div>
    </div>`;
}

function validateTrackId(value) {
  const id = String(value || "").trim();
  if (!id) return "Please enter your delivery track ID.";
  if (!/^\d+$/.test(id)) return "Delivery track ID must contain numbers only.";
  if (id.length !== 12) return "Delivery track ID must be exactly 12 digits.";
  return "";
}

async function track() {
  const result = document.getElementById("trackResult");
  const input = document.getElementById("trackInput");
  if (input) input.value = trackId;

  const validationError = validateTrackId(trackId);
  if (validationError) {
    result.innerHTML = `<div class="track-empty"><h2>Invalid track ID</h2><p>${esc(validationError)}</p></div>`;
    return;
  }

  if (!trackId) {
    result.innerHTML = `<div class="track-empty"><h2>Enter your delivery track ID</h2><p>Your 12-digit tracking ID can be used anytime to check the latest status.</p></div>`;
    return;
  }

  result.innerHTML = `<div class="track-loading">Checking latest delivery status…</div>`;

  try {
    const response = await fetch(`/api/track?delivery_track_id=${encodeURIComponent(trackId)}`, { cache: "no-store" });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.success || !data.order) throw new Error(data.message || "Tracking ID not found");
    renderOrder(data.order);
  } catch (error) {
    result.innerHTML = `<div class="track-empty"><h2>Tracking ID not found</h2><p>${esc(error.message || "Unable to load tracking information.")}</p></div>`;
  }
}

document.getElementById("trackForm")?.addEventListener("submit", e => {
  e.preventDefault();
  const input = document.getElementById("trackInput");
  const errorBox = document.getElementById("trackInputError");
  const value = input?.value.trim() || "";
  const error = validateTrackId(value);

  input?.classList.toggle("input-error", Boolean(error));
  if (errorBox) {
    errorBox.textContent = error;
    errorBox.classList.toggle("active", Boolean(error));
  }

  if (error) {
    input?.focus();
    return;
  }

  location.href = `/track.html?id=${encodeURIComponent(value)}`;
});

document.getElementById("trackInput")?.addEventListener("input", e => {
  const input = e.currentTarget;
  const errorBox = document.getElementById("trackInputError");
  input.value = input.value.replace(/\D/g, "").slice(0, 12);
  input.classList.remove("input-error");
  if (errorBox) {
    errorBox.textContent = "";
    errorBox.classList.remove("active");
  }
});

track();
