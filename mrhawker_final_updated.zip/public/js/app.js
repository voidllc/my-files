let products = [];
let randomizedProducts = [];
let cart = JSON.parse(localStorage.getItem("mrHawkerCart") || "[]");
let sliderIndex = 0;
let sliderTimer = null;
let sliderRealCount = 0;
let allProductsExpanded = false;

const driveImage = id => id
  ? `https://lh3.googleusercontent.com/d/${encodeURIComponent(id)}`
  : "https://via.placeholder.com/900x900?text=No+Image";

const imageIds = p => (p.images || "").split(",").map(x => x.trim()).filter(Boolean);
const productImage = p => driveImage(imageIds(p)[0]);
const finalPrice = p => {
  const price = Number(p.price) || 0;
  const discount = Number(p.discount) || 0;
  return discount > 0 ? price - (price * discount / 100) : price;
};
const money = value => "৳" + Number(value).toLocaleString("en-BD", { maximumFractionDigits: 0 });
const esc = value => String(value ?? "").replace(/[&<>"']/g, m => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
}[m]));

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

async function loadProducts() {
  try {
    const response = await fetch("/api/products", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.message || "Unable to load products");

    products = Array.isArray(data.products) ? data.products : [];
    randomizedProducts = shuffle(products);

    displayFeatured();
    displayFlash();
    displayCategories();
    displayProducts();
    displayNew();
    updateCart();

    const query = new URLSearchParams(location.search).get("q") || "";
    if (query) {
      const input = document.getElementById("searchInput");
      if (input) input.value = query;
      performSearch(query);
    }
  } catch (error) {
    console.error("Product loading error:", error);
    const grid = document.getElementById("productsGrid");
    if (grid) grid.innerHTML = `<p class="muted-message">Unable to load products.</p>`;
  }
}

/* =========================================================
   FEATURED SLIDER — featured = 1 + featured_img required
========================================================= */
function displayFeatured() {
  const featured = products.filter(p => Number(p.featured) === 1 && p.featured_img);
  const track = document.getElementById("sliderTrack");
  const dots = document.getElementById("sliderDots");
  if (!track || !dots) return;

  clearInterval(sliderTimer);
  sliderTimer = null;
  sliderRealCount = featured.length;
  sliderIndex = 0;

  if (!featured.length) {
    track.innerHTML = "";
    dots.innerHTML = "";
    return;
  }

  if (featured.length === 1) {
    track.innerHTML = `<div class="hero-slide"><img src="${driveImage(featured[0].featured_img)}" alt="" draggable="false"></div>`;
    dots.innerHTML = `<button class="slider-dot active" aria-label="Slide 1"></button>`;
    track.style.transform = "translateX(0)";
    track.style.transition = "none";
    return;
  }

  const slides = [featured[featured.length - 1], ...featured, featured[0]];
  track.innerHTML = slides.map(p =>
    `<div class="hero-slide"><img src="${driveImage(p.featured_img)}" alt="" draggable="false"></div>`
  ).join("");

  dots.innerHTML = featured.map((_, i) =>
    `<button class="slider-dot ${i === 0 ? "active" : ""}" onclick="goSlide(${i})" aria-label="Slide ${i + 1}"></button>`
  ).join("");

  sliderIndex = 1;
  track.style.transition = "none";
  track.style.transform = "translateX(-100%)";

  requestAnimationFrame(() => requestAnimationFrame(() => {
    track.style.transition = "transform .55s ease";
  }));

  sliderTimer = setInterval(nextSlide, 4500);
}

function updateDots(realIndex) {
  document.querySelectorAll(".slider-dot").forEach((dot, i) => {
    dot.classList.toggle("active", i === realIndex);
  });
}

function goSlide(realIndex) {
  if (sliderRealCount <= 1) return;
  const track = document.getElementById("sliderTrack");
  if (!track) return;
  sliderIndex = realIndex + 1;
  track.style.transition = "transform .55s ease";
  track.style.transform = `translateX(-${sliderIndex * 100}%)`;
  updateDots(realIndex);
}

function nextSlide() {
  if (sliderRealCount <= 1) return;
  const track = document.getElementById("sliderTrack");
  if (!track) return;

  sliderIndex++;
  track.style.transition = "transform .55s ease";
  track.style.transform = `translateX(-${sliderIndex * 100}%)`;
  updateDots((sliderIndex - 1 + sliderRealCount) % sliderRealCount);

  if (sliderIndex === sliderRealCount + 1) {
    setTimeout(() => {
      track.style.transition = "none";
      sliderIndex = 1;
      track.style.transform = "translateX(-100%)";
      requestAnimationFrame(() => requestAnimationFrame(() => {
        track.style.transition = "transform .55s ease";
      }));
    }, 570);
  }
}

/* =========================================================
   PRODUCT CARD
========================================================= */
function getQty(id) {
  return cart.find(item => Number(item.id) === Number(id))?.quantity || 0;
}

function productCard(product) {
  const id = product.rowid ?? product.id;
  const rawPrice = Number(product.price) || 0;
  const discount = Number(product.discount) || 0;
  const quantity = getQty(id);

  return `<article class="product-card">
    <a href="/product.html?id=${encodeURIComponent(id)}" class="product-image">
      <img src="${productImage(product)}" alt="${esc(product.name)}" loading="lazy">
      ${discount > 0 ? `<span class="discount-badge">-${discount}%</span>` : ""}
    </a>
    <div class="product-info">
      <span class="product-category">${esc(product.category_name || "Product")}</span>
      <h3 class="product-name">${esc(product.name)}</h3>
      <div class="product-bottom">
        <div class="product-price">
          ${money(finalPrice(product))}
          ${discount > 0 ? `<span class="old-price">${money(rawPrice)}</span>` : ""}
        </div>
        ${quantity > 0
          ? `<div class="quantity-control">
              <button onclick="changeQty(${Number(id)},-1)" aria-label="Decrease quantity">−</button>
              <span>${quantity}</span>
              <button onclick="changeQty(${Number(id)},1)" aria-label="Increase quantity" ${quantity >= Number(product.stock ?? 0) ? "disabled" : ""}>+</button>
            </div>`
          : Number(product.stock ?? 0) > 0
            ? `<button class="add-cart-button" onclick="addToCart(${Number(id)})" aria-label="Add to cart">+</button>`
            : `<span class="out-of-stock">Out of stock</span>`}
      </div>
    </div>
  </article>`;
}

function displayFlash() {
  const container = document.getElementById("flashProducts");
  if (!container) return;
  const items = products.filter(p => Number(p.featured) === 2);
  container.innerHTML = items.length
    ? items.map(productCard).join("")
    : `<p class="muted-message">No flash sale products available.</p>`;
}

function displayNew() {
  const container = document.getElementById("newProducts");
  if (!container) return;
  const items = products.filter(p => Number(p.featured) === 3);
  container.innerHTML = items.length
    ? items.map(productCard).join("")
    : `<p class="muted-message">No new arrivals yet.</p>`;
}

/* =========================================================
   ALL PRODUCTS — every featured value is included
========================================================= */
function displayProducts(list = products) {
  const container = document.getElementById("productsGrid");
  const button = document.getElementById("viewAllButton");
  if (!container) return;

  const source = Array.isArray(list) ? list : [];
  const isAllProducts = source.length === products.length && source.every((item, index) => item === products[index]);
  const randomItems = isAllProducts ? randomizedProducts : shuffle(source);
  const hasMore = isAllProducts && randomItems.length > 20 && !allProductsExpanded;
  const visible = hasMore ? randomItems.slice(0, 20) : randomItems;

  container.innerHTML = visible.length
    ? visible.map(productCard).join("")
    : `<p class="muted-message">No products available.</p>`;

  if (button) {
    button.hidden = !hasMore;
  }
}

function displayCategories() {
  const container = document.getElementById("categoriesList");
  if (!container) return;

  const map = new Map();
  products.forEach(product => {
    const id = String(product.category_id ?? "").trim();
    if (id && !map.has(id)) map.set(id, product);
  });

  container.innerHTML = [...map.values()].map(product => {
    const categoryId = String(product.category_id ?? "");
    const imageId = product.category_img || imageIds(product)[0];
    return `<button class="category-item" onclick="filterCategory('${esc(categoryId)}')">
      <span class="category-image"><img src="${driveImage(imageId)}" alt="${esc(product.category_name || "Category")}" loading="lazy"></span>
      <span class="category-name">${esc(product.category_name || "Category")}</span>
    </button>`;
  }).join("");
}

function filterCategory(categoryId) {
  allProductsExpanded = false;
  const filtered = products.filter(p => String(p.category_id ?? "") === String(categoryId));
  displayProducts(filtered);
  document.getElementById("products")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function performSearch(value) {
  const query = (value ?? document.getElementById("searchInput")?.value ?? "").trim().toLowerCase();
  const filtered = query
    ? products.filter(p => (`${p.name || ""} ${p.description || ""} ${p.category_name || ""}`).toLowerCase().includes(query))
    : products;
  allProductsExpanded = false;
  displayProducts(filtered);
  if (query) document.getElementById("products")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function addToCart(id) {
  const product = products.find(p => Number(p.rowid ?? p.id) === Number(id));
  if (!product) return;
  const stock = Number(product.stock ?? 0);
  if (stock <= 0) return;
  const item = cart.find(x => Number(x.id) === Number(id));
  if (item) item.quantity++;
  else cart.push({ id: Number(id), quantity: 1 });
  saveCart();
  refresh();
}

function changeQty(id, amount) {
  const item = cart.find(x => Number(x.id) === Number(id));
  if (!item) return;
  const product = products.find(p => Number(p.rowid ?? p.id) === Number(id));
  if (amount > 0 && product && item.quantity >= Number(product.stock ?? 0)) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(x => Number(x.id) !== Number(id));
  saveCart();
  refresh();
}

function saveCart() {
  localStorage.setItem("mrHawkerCart", JSON.stringify(cart));
}

function refresh() {
  updateCart();
  displayFlash();
  displayProducts();
  displayNew();
}

function updateCart() {
  const count = cart.reduce((total, item) => total + Number(item.quantity || 0), 0);
  document.querySelectorAll("#cartCount").forEach(el => el.textContent = count);

  const container = document.getElementById("cartItems");
  if (!container) return;

  if (!cart.length) {
    container.innerHTML = `<div class="empty-cart">Your cart is empty.</div>`;
    const total = document.getElementById("cartTotal");
    if (total) total.textContent = "৳0";
    return;
  }

  let total = 0;
  container.innerHTML = cart.map(item => {
    const product = products.find(p => Number(p.rowid ?? p.id) === Number(item.id));
    if (!product) return "";
    const itemTotal = finalPrice(product) * item.quantity;
    total += itemTotal;
    return `<div class="cart-item">
      <div class="cart-item-image"><img src="${productImage(product)}" alt="${esc(product.name)}"></div>
      <div class="cart-item-info">
        <div class="cart-item-name">${esc(product.name)}</div>
        <div class="cart-item-price">${money(itemTotal)}</div>
        <div class="quantity-control">
          <button onclick="changeQty(${Number(item.id)},-1)">−</button>
          <span>${item.quantity}</span>
          <button onclick="changeQty(${Number(item.id)},1)">+</button>
        </div>
      </div>
    </div>`;
  }).join("");

  const totalBox = document.getElementById("cartTotal");
  if (totalBox) totalBox.textContent = money(total);
}

function openCart() {
  document.getElementById("cartDrawer")?.classList.add("active");
  document.getElementById("cartOverlay")?.classList.add("active");
  document.body.classList.add("drawer-open");
}
function closeCart() {
  document.getElementById("cartDrawer")?.classList.remove("active");
  document.getElementById("cartOverlay")?.classList.remove("active");
  document.body.classList.remove("drawer-open");
}

/* =========================================================
   EVENTS
========================================================= */
document.getElementById("cartButton")?.addEventListener("click", openCart);
document.getElementById("closeCart")?.addEventListener("click", closeCart);
document.getElementById("cartOverlay")?.addEventListener("click", closeCart);
document.getElementById("drawerCheckout")?.addEventListener("click", () => {
  if (cart.length) location.href = "/checkout.html";
});
document.getElementById("viewAllButton")?.addEventListener("click", () => {
  allProductsExpanded = true;
  displayProducts(products);
  document.getElementById("viewAllButton")?.scrollIntoView({ behavior: "smooth", block: "center" });
});
document.getElementById("searchButton")?.addEventListener("click", () => {
  const panel = document.getElementById("searchPanel");
  panel?.classList.toggle("active");
  if (panel?.classList.contains("active")) document.getElementById("searchInput")?.focus();
});
document.getElementById("searchInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") performSearch();
});

function validateTrackId(value) {
  const id = String(value || "").trim();
  if (!id) return "Please enter your delivery track ID.";
  if (!/^\d+$/.test(id)) return "Delivery track ID must contain numbers only.";
  if (id.length !== 12) return "Delivery track ID must be exactly 12 digits.";
  return "";
}

function showTrackInputError(message) {
  const input = document.getElementById("trackInput");
  const errorBox = document.getElementById("trackInputError");

  input?.classList.toggle("input-error", Boolean(message));

  if (errorBox) {
    errorBox.textContent = message || "";
    errorBox.classList.toggle("active", Boolean(message));
  }
}

document.getElementById("trackButton")?.addEventListener("click", () => {
  const input = document.getElementById("trackInput");
  const value = input?.value.trim() || "";
  const error = validateTrackId(value);

  showTrackInputError(error);

  if (error) {
    input?.focus();
    return;
  }

  location.href = `/track.html?id=${encodeURIComponent(value)}`;
});

document.getElementById("trackInput")?.addEventListener("input", e => {
  const input = e.currentTarget;
  input.value = input.value.replace(/\D/g, "").slice(0, 12);
  showTrackInputError("");
});

document.getElementById("trackInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") {
    e.preventDefault();
    document.getElementById("trackButton")?.click();
  }
});

loadProducts();
