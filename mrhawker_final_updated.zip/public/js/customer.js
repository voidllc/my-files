const cart = JSON.parse(localStorage.getItem("mrHawkerCart") || "[]");
const count = cart.reduce((total, item) => total + Number(item.quantity || 0), 0);
document.querySelectorAll("#cartCount").forEach(el => el.textContent = count);

document.getElementById("customerForm")?.addEventListener("submit", event => {
  event.preventDefault();
  if (!cart.length) {
    alert("Your cart is empty.");
    location.href = "/checkout.html";
    return;
  }

  const data = Object.fromEntries(new FormData(event.currentTarget));
  localStorage.setItem("mrHawkerCustomer", JSON.stringify(data));
  location.href = "/payment.html";
});

document.getElementById("searchButton")?.addEventListener("click", () => {
  const panel = document.getElementById("searchPanel");
  panel?.classList.toggle("active");
  if (panel?.classList.contains("active")) document.getElementById("searchInput")?.focus();
});
document.getElementById("searchInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") {
    const q = e.currentTarget.value.trim();
    if (q) location.href = `/?q=${encodeURIComponent(q)}`;
  }
});
