let products=[];let cart=JSON.parse(localStorage.getItem("mrHawkerCart")||"[]");
const driveImage=id=>id?`https://lh3.googleusercontent.com/d/${encodeURIComponent(id)}`:"https://via.placeholder.com/900x900?text=No+Image";
const imgs=p=>(p.images||"").split(",").map(x=>x.trim()).filter(Boolean);
const price=p=>{const x=Number(p.price)||0,d=Number(p.discount)||0;return d?x-x*d/100:x};
const money=v=>"৳"+Number(v).toLocaleString("en-BD",{maximumFractionDigits:0});
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const qty=id=>cart.find(x=>Number(x.id)===Number(id))?.quantity||0;

function save(){localStorage.setItem("mrHawkerCart",JSON.stringify(cart));renderCartDrawer();updateCartCount()}
function add(id){const x=cart.find(i=>Number(i.id)===Number(id));x?x.quantity++:cart.push({id:Number(id),quantity:1});save();renderProduct()}
function change(id,n){const x=cart.find(i=>Number(i.id)===Number(id));if(!x)return;x.quantity+=n;if(x.quantity<=0)cart=cart.filter(i=>Number(i.id)!==Number(id));save();renderProduct()}
function updateCartCount(){document.querySelectorAll("#cartCount").forEach(e=>e.textContent=cart.reduce((a,x)=>a+Number(x.quantity||0),0))}

function productCard(p){
 const id=p.rowid??p.id,d=Number(p.discount)||0;
 return `<article class="product-card"><a href="/product.html?id=${encodeURIComponent(id)}" class="product-image"><img src="${driveImage(imgs(p)[0])}" alt="${esc(p.name)}" loading="lazy">${d?`<span class="discount-badge">-${d}%</span>`:""}</a><div class="product-info"><span class="product-category">${esc(p.category_name||"Product")}</span><h3 class="product-name">${esc(p.name)}</h3><div class="product-bottom"><strong class="product-price">${money(price(p))}${d?`<span class="old-price">${money(p.price)}</span>`:""}</strong>${qty(id)?`<div class="quantity-control"><button onclick="change(${id},-1)">−</button><span>${qty(id)}</span><button onclick="change(${id},1)">+</button></div>`:`<button class="add-cart-button" onclick="add(${id})" aria-label="Add to cart">+</button>`}</div></div></article>`
}

function renderProduct(){
 const id=new URLSearchParams(location.search).get("id");
 const p=products.find(x=>String(x.rowid??x.id)===String(id));
 const box=document.getElementById("productDetail");
 if(!p){box.innerHTML="<div class='detail-card'><h1>Product not found</h1></div>";return}
 const images=imgs(p),d=Number(p.discount)||0;
 box.innerHTML=`<div class="gallery-card"><div class="main-product-image"><img id="mainImage" src="${driveImage(images[0])}" alt="${esc(p.name)}"></div><div class="thumb-list">${images.slice(0,3).map((x,i)=>`<button class="thumb ${i===0?"active":""}" onclick="selectImage('${esc(x)}',this)"><img src="${driveImage(x)}" alt=""></button>`).join("")}</div></div>
 <div class="detail-card"><span class="eyebrow">${esc(p.category_name||"PRODUCT")}</span><h1>${esc(p.name)}</h1><div class="detail-price">${money(price(p))}${d?`<span class="detail-old">${money(p.price)}</span>`:""}</div>${d?`<span class="discount-badge detail-discount">-${d}% OFF</span>`:""}<div class="detail-actions"><button class="primary-button" onclick="add(${p.rowid??p.id})">Add to Cart</button><button class="secondary-button" onclick="add(${p.rowid??p.id});location.href='/checkout.html'">Buy Now</button></div></div>
 <div class="detail-card product-details-card"><div class="details-section"><h3>Product Details</h3><div class="html-description">${p.description||"No additional details available."}</div></div></div>`;
 const related=products.filter(x=>String(x.category_id)===String(p.category_id)&&String(x.rowid??x.id)!==String(p.rowid??p.id)).slice(0,8);
 document.getElementById("relatedProducts").innerHTML=related.map(productCard).join("")||"<p class='muted-message'>No related products.</p>";
 renderCartDrawer();
}

function selectImage(id,b){document.getElementById("mainImage").src=driveImage(id);document.querySelectorAll(".thumb").forEach(x=>x.classList.remove("active"));b.classList.add("active")}

function renderCartDrawer(){
 const c=document.getElementById("cartItems");if(!c)return;
 if(!cart.length){c.innerHTML='<div class="empty-cart">Your cart is empty.</div>';document.getElementById("cartTotal").textContent="৳0";return}
 let total=0;
 c.innerHTML=cart.map(i=>{const p=products.find(x=>Number(x.rowid??x.id)===Number(i.id));if(!p)return"";const t=price(p)*i.quantity;total+=t;return `<div class="cart-item"><div class="cart-item-image"><img src="${driveImage(imgs(p)[0])}" alt=""></div><div class="cart-item-info"><div class="cart-item-name">${esc(p.name)}</div><div class="cart-item-price">${money(t)}</div><div class="quantity-control"><button onclick="change(${i.id},-1)">−</button><span>${i.quantity}</span><button onclick="change(${i.id},1)">+</button></div></div></div>`}).join("");
 document.getElementById("cartTotal").textContent=money(total);
}
function openCart(){document.getElementById("cartDrawer")?.classList.add("active");document.getElementById("cartOverlay")?.classList.add("active");document.body.classList.add("drawer-open")}
function closeCart(){document.getElementById("cartDrawer")?.classList.remove("active");document.getElementById("cartOverlay")?.classList.remove("active");document.body.classList.remove("drawer-open")}
document.getElementById("cartButton")?.addEventListener("click",openCart);
document.getElementById("closeCart")?.addEventListener("click",closeCart);
document.getElementById("cartOverlay")?.addEventListener("click",closeCart);
document.getElementById("drawerCheckout")?.addEventListener("click",()=>{if(cart.length)location.href="/checkout.html"});
document.getElementById("searchButton")?.addEventListener("click",()=>{const p=document.getElementById("searchPanel");p?.classList.toggle("active");if(p?.classList.contains("active"))document.getElementById("searchInput")?.focus()});
document.getElementById("searchInput")?.addEventListener("keydown",e=>{if(e.key==="Enter"){const q=e.currentTarget.value.trim();if(q)location.href="/?q="+encodeURIComponent(q)}});

async function load(){try{const r=await fetch("/api/products"),d=await r.json();if(!r.ok||!d.success)throw Error(d.message);products=d.products||[];updateCartCount();renderProduct()}catch(e){console.error("Product loading error:",e)}}
load();