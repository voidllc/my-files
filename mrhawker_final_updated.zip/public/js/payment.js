let cart = JSON.parse(localStorage.getItem("mrHawkerCart") || "[]");
let customer = JSON.parse(localStorage.getItem("mrHawkerCustomer") || "{}");
let products = [];

const price = p => {
  const x = Number(p.price) || 0;
  const d = Number(p.discount) || 0;
  return d ? x - x * d / 100 : x;
};
const money = value => "৳" + Number(value).toLocaleString("en-BD", { maximumFractionDigits: 0 });

function updateCartCount() {
  const count = cart.reduce((total, item) => total + Number(item.quantity || 0), 0);
  document.querySelectorAll("#cartCount").forEach(el => el.textContent = count);
}

async function load() {
  try {
    const response = await fetch("/api/products", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.message || "Unable to load products");
    products = data.products || [];

    let total = 0;
    cart.forEach(item => {
      const product = products.find(x => Number(x.rowid ?? x.id) === Number(item.id));
      if (product) total += price(product) * item.quantity;
    });
    document.getElementById("paymentTotal").textContent = money(total);
    updateCartCount();
  } catch (error) {
    console.error(error);
  }
}

document.querySelectorAll('input[name="payment_type"]').forEach(input => {
  input.addEventListener("change", () => {
    const cod = document.querySelector('input[name="payment_type"]:checked')?.value === "2";
    document.getElementById("trxWrap")?.classList.toggle("hidden", cod);
    document.getElementById("trxId").required = !cod;
  });
});

function showPaymentError(message) {
  let box = document.getElementById("paymentError");
  if (!box) {
    box = document.createElement("div");
    box.id = "paymentError";
    box.className = "field-error active";
    const form = document.getElementById("paymentForm");
    form?.prepend(box);
  }
  box.textContent = message || "";
  box.classList.toggle("active", Boolean(message));
}

document.getElementById("paymentForm")?.addEventListener("submit", async event => {
  event.preventDefault();

  if (!cart.length) {
    showPaymentError("Your cart is empty. Please add a product before placing an order.");
    return;
  }

  if (!customer.name || !customer.phone || !customer.email || !customer.address) {
    showPaymentError("Customer details are missing. Please go back and enter them again.");
    return;
    return;
  }

  const paymentType = Number(document.querySelector('input[name="payment_type"]:checked')?.value);
  const trxId = paymentType === 2 ? "CASH_ON_DELIVERY" : document.getElementById("trxId").value.trim();
  if (![1, 2, 3].includes(paymentType)) {
    showPaymentError("Select a valid payment method.");
    return;
  }
  if (paymentType !== 2 && !trxId) {
    showPaymentError("Enter transaction ID.");
    document.getElementById("trxId")?.focus();
    return;
  }

  const orders = [];
  let clientTotal = 0;

  for (const item of cart) {
    const product = products.find(x => Number(x.rowid ?? x.id) === Number(item.id));
    if (!product) {
      showPaymentError("One of the products is no longer available. Please review your cart.");
      return;
    }
    clientTotal += price(product) * item.quantity;
    orders.push({ product_id: Number(item.id), quantity: Number(item.quantity) });
  }

  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  button.textContent = "Placing order…";

  try {
    const response = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: customer.name,
        phone: customer.phone,
        email: customer.email,
        address: customer.address,
        orders: JSON.stringify(orders),
        amount: clientTotal,
        payment_type: paymentType,
        payment_status: "pending",
        delivery_status: "pending",
        trx_id: trxId,
        delivery_date: null,
        delivery_track_id: null
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.success || !data.order) {
      throw new Error(data.detail ? `${data.message || "Unable to place order"}: ${data.detail}` : (data.message || "Unable to place order"));
    }

    /* The Worker must generate delivery_track_id server-side. */
    const trackId = data.order.delivery_track_id;
    if (!trackId) throw new Error("Order was created but no delivery tracking ID was returned.");

    localStorage.removeItem("mrHawkerCart");
    localStorage.removeItem("mrHawkerCustomer");

    document.getElementById("successTrackId").textContent = trackId;
    document.getElementById("successOverlay").classList.add("active");
    document.getElementById("trackOrderButton").onclick = () => {
      location.href = `/track.html?id=${encodeURIComponent(trackId)}`;
    };
  } catch (error) {
    console.error("Place order error:", error);
    showPaymentError(error.message || "Unable to place order");
    button.disabled = false;
    button.textContent = "Place Order";
  }
});

document.getElementById("searchButton")?.addEventListener("click", () => {
  const panel = document.getElementById("searchPanel");
  panel?.classList.toggle("active");
  if (panel?.classList.contains("active")) document.getElementById("searchInput")?.focus();
});
document.getElementById("searchInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") {
    const q = e.currentTarget.value.trim();
    if (q) location.href = `/?q=${encodeURIComponent(q)}`;
  }
});

load();
