let cart = JSON.parse(localStorage.getItem("mrHawkerCart") || "[]");
let products = [];

const img = id => id ? `https://lh3.googleusercontent.com/d/${encodeURIComponent(id)}` : "https://via.placeholder.com/100x100?text=No+Image";
const price = p => {
  const x = Number(p.price) || 0;
  const d = Number(p.discount) || 0;
  return d ? x - x * d / 100 : x;
};
const money = value => "৳" + Number(value).toLocaleString("en-BD", { maximumFractionDigits: 0 });
const esc = value => String(value ?? "").replace(/[&<>"']/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

function updateHeaderCount() {
  const count = cart.reduce((total, item) => total + Number(item.quantity || 0), 0);
  document.querySelectorAll("#cartCount").forEach(el => el.textContent = count);
}

async function load() {
  try {
    const response = await fetch("/api/products", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.message || "Unable to load products");
    products = data.products || [];
    render();
  } catch (error) {
    console.error(error);
    document.getElementById("checkoutItems").innerHTML = `<div class="empty-checkout">Unable to load your order.</div>`;
  }
}

function render() {
  const box = document.getElementById("checkoutItems");
  let total = 0;

  if (!cart.length) {
    box.innerHTML = '<div class="empty-checkout">Your cart is empty.</div>';
    setTotals(0);
    return;
  }

  box.innerHTML = cart.map(item => {
    const product = products.find(x => Number(x.rowid ?? x.id) === Number(item.id));
    if (!product) return "";
    const itemTotal = price(product) * item.quantity;
    total += itemTotal;
    const firstImage = (product.images || "").split(",")[0]?.trim();

    return `<div class="checkout-row">
      <img src="${img(firstImage)}" alt="${esc(product.name)}">
      <div class="checkout-row-info">
        <strong>${esc(product.name)}</strong>
        <small>${money(price(product))} each</small>
      </div>
      <div class="quantity-control">
        <button onclick="change(${Number(item.id)},-1)">−</button>
        <span>${item.quantity}</span>
        <button onclick="change(${Number(item.id)},1)">+</button>
      </div>
      <strong>${money(itemTotal)}</strong>
    </div>`;
  }).join("");

  setTotals(total);
}

function setTotals(total) {
  document.getElementById("checkoutTotal").textContent = money(total);
  document.getElementById("checkoutStickyTotal").textContent = money(total);
  updateHeaderCount();
  document.getElementById("checkoutContinue").disabled = !cart.length;
}

function change(id, amount) {
  const item = cart.find(x => Number(x.id) === Number(id));
  if (!item) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(x => Number(x.id) !== Number(id));
  localStorage.setItem("mrHawkerCart", JSON.stringify(cart));
  render();
}

document.getElementById("checkoutContinue")?.addEventListener("click", () => {
  if (cart.length) location.href = "/customer.html";
});

document.getElementById("searchButton")?.addEventListener("click", () => {
  const panel = document.getElementById("searchPanel");
  panel?.classList.toggle("active");
  if (panel?.classList.contains("active")) document.getElementById("searchInput")?.focus();
});
document.getElementById("searchInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") {
    const q = e.currentTarget.value.trim();
    if (q) location.href = `/?q=${encodeURIComponent(q)}`;
  }
});

load();
