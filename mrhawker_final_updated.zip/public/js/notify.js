/**
 * Notification bridge.
 * Email + Android-admin FCM are intentionally not sent yet.
 * When the backend notification service is ready, only this function
 * needs to be connected to /api/notify.
 */
async function notifyOrderCreated(deliveryTrackId) {
  if (!/^\d{12}$/.test(String(deliveryTrackId || ""))) {
    return { success: false, status: "invalid_track_id" };
  }

  return {
    success: true,
    status: "pending_integration",
    delivery_track_id: String(deliveryTrackId)
  };
}
