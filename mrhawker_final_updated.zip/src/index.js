const TRACK_ID_LENGTH = 12;

function json(data, status = 200) {
  return Response.json(data, { status });
}

function textOrNull(value) {
  if (value === undefined || value === null || String(value).trim() === "") return "NULL";
  return String(value).trim();
}

function finalProductPrice(product) {
  const price = Number(product.price) || 0;
  const discount = Number(product.discount) || 0;
  return discount > 0 ? price - (price * discount / 100) : price;
}

function parseDeliveryStatus(value) {
  if (value && typeof value === "object") return value;
  if (typeof value !== "string") return { status: "pending" };
  try {
    const parsed = JSON.parse(value);
    if (parsed && typeof parsed === "object") return parsed;
  } catch {}
  return { status: value.trim() || "pending" };
}

function statusName(value) {
  return String(parseDeliveryStatus(value).status || "pending").toLowerCase().trim();
}

function parseDeliveryData(value) {
  if (value && typeof value === "object") return value;
  if (value === undefined || value === null) return {};
  const text = String(value).trim();
  if (!text || text === "NULL" || text.toLowerCase() === "null") return {};
  try {
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function normalizeDeliveryData(value) {
  const data = parseDeliveryData(value);
  return Object.keys(data).length ? JSON.stringify(data) : "NULL";
}

async function ensureOrderTrackingSchema(db) {
  const info = await db.prepare(`PRAGMA table_info(mr_hawker_orders)`).all();
  const columns = info.results || [];
  if (!columns.length) throw new Error("mr_hawker_orders table was not found");

  if (!columns.some(column => column.name === "delivery_track_id")) {
    await db.prepare(`ALTER TABLE mr_hawker_orders ADD COLUMN delivery_track_id TEXT`).run();
  }

  // delivery_data stores JSON only for rejected and shipped_to_rider orders.
  // Existing installations can be upgraded automatically.
  if (!columns.some(column => column.name === "delivery_data")) {
    await db.prepare(`ALTER TABLE mr_hawker_orders ADD COLUMN delivery_data TEXT DEFAULT 'NULL'`).run();
  }

  try {
    await db.prepare(`
      CREATE UNIQUE INDEX IF NOT EXISTS
      idx_mr_hawker_orders_delivery_track_id
      ON mr_hawker_orders(delivery_track_id)
    `).run();
  } catch (error) {
    console.warn("Delivery track unique index could not be created:", error);
  }
}

async function generateUniqueDeliveryTrackId(db) {
  for (let attempt = 0; attempt < 50; attempt++) {
    const bytes = new Uint8Array(TRACK_ID_LENGTH);
    crypto.getRandomValues(bytes);
    let id = String((bytes[0] % 9) + 1);
    for (let i = 1; i < TRACK_ID_LENGTH; i++) id += String(bytes[i] % 10);

    const existing = await db.prepare(`
      SELECT rowid FROM mr_hawker_orders
      WHERE delivery_track_id = ? LIMIT 1
    `).bind(id).first();

    if (!existing) return id;
  }
  throw new Error("Unable to generate a unique delivery track ID");
}

async function calculateServerOrder(db, ordersJson) {
  let items;
  try {
    items = typeof ordersJson === "string" ? JSON.parse(ordersJson) : ordersJson;
  } catch {
    throw new Error("Invalid orders data");
  }

  if (!Array.isArray(items) || items.length === 0) {
    throw new Error("Order items are required");
  }

  const normalized = [];
  let total = 0;

  for (const item of items) {
    const productId = Number(item?.product_id ?? item?.id);
    const quantity = Number(item?.quantity);

    if (!Number.isInteger(productId) || productId <= 0 ||
        !Number.isInteger(quantity) || quantity <= 0) {
      throw new Error("Invalid order item");
    }

    const product = await db.prepare(`
      SELECT rowid, name, price, discount, stock, status
      FROM mr_hawker_test
      WHERE rowid = ? LIMIT 1
    `).bind(productId).first();

    if (!product || Number(product.status) !== 1) {
      throw new Error(`Product ${productId} is unavailable`);
    }

    const stock = Number(product.stock ?? 0);
    if (quantity > stock) {
      throw new Error(`${product.name} has insufficient stock`);
    }

    const unitPrice = finalProductPrice(product);
    total += unitPrice * quantity;

    normalized.push({
      product_id: productId,
      quantity,
      unit_price: Number(unitPrice.toFixed(2))
    });
  }

  return {
    total: Number(total.toFixed(2)),
    normalized
  };
}

async function addRequiredLegacyColumns(db, columnValues) {
  const info = await db.prepare(`PRAGMA table_info(mr_hawker_orders)`).all();
  const columns = info.results || [];

  for (const column of columns) {
    const name = column.name;
    if (name === "rowid" || Object.prototype.hasOwnProperty.call(columnValues, name)) continue;

    if (Number(column.notnull) === 1 && column.dflt_value === null) {
      columnValues[name] = "NULL";
    }
  }
  return columnValues;
}

function makeInsertStatement(db, values) {
  const columns = Object.keys(values);
  const placeholders = columns.map(column =>
    column === "order_date" ? "CURRENT_TIMESTAMP" : "?"
  ).join(", ");
  const bindings = columns.filter(column => column !== "order_date").map(column => values[column]);

  return db.prepare(`
    INSERT INTO mr_hawker_orders (${columns.join(", ")})
    VALUES (${placeholders})
    RETURNING rowid, *
  `).bind(...bindings);
}

async function createOrder(request, env) {
  let data;
  try {
    data = await request.json();
  } catch {
    return json({ success: false, message: "Invalid JSON request" }, 400);
  }

  const name = textOrNull(data.name);
  const phone = textOrNull(data.phone);
  const email = textOrNull(data.email);
  const address = textOrNull(data.address);

  if (name === "NULL" || phone === "NULL" || email === "NULL" || address === "NULL" ||
      data.orders === undefined || data.orders === null) {
    return json({ success: false, message: "Please complete all customer details" }, 400);
  }

  const paymentType = Number(data.payment_type);
  if (![1, 2, 3].includes(paymentType)) {
    return json({ success: false, message: "Invalid payment type" }, 400);
  }

  const trxId = paymentType === 2 ? "CASH_ON_DELIVERY" : textOrNull(data.trx_id);
  if (paymentType !== 2 && trxId === "NULL") {
    return json({ success: false, message: "Transaction ID is required" }, 400);
  }

  let calculated;
  try {
    calculated = await calculateServerOrder(env.DB, data.orders);
  } catch (error) {
    console.error("Order price/stock verification error:", error);
    return json({ success: false, message: error.message || "Unable to verify order items" }, 400);
  }

  const clientAmount = Number(data.amount);
  if (!Number.isFinite(clientAmount) || clientAmount < 0) {
    return json({ success: false, message: "Invalid amount" }, 400);
  }

  try {
    await ensureOrderTrackingSchema(env.DB);
  } catch (error) {
    console.error("Order schema check error:", error);
    return json({
      success: false,
      message: "Unable to place order",
      detail: error.message || "Order database schema is not ready"
    }, 500);
  }

  const deliveryTrackId = await generateUniqueDeliveryTrackId(env.DB);

  const orderValues = await addRequiredLegacyColumns(env.DB, {
    name,
    phone,
    email,
    address,
    orders: JSON.stringify(calculated.normalized),
    order_date: "CURRENT_TIMESTAMP",
    delivery_date: "NULL",
    delivery_status: "pending",
    delivery_data: "NULL",
    amount: calculated.total,
    payment_type: paymentType,
    payment_status: "pending",
    trx_id: trxId,
    delivery_track_id: deliveryTrackId
  });

  /*
   * Insert the order and decrement every product's stock in ONE D1 batch.
   * D1 batch operations are atomic: if any stock update fails, the order
   * insert is not committed either.
   */
  const statements = [makeInsertStatement(env.DB, orderValues)];
  for (const item of calculated.normalized) {
    statements.push(
      env.DB.prepare(`
        UPDATE mr_hawker_test
        SET stock = stock - ?
        WHERE rowid = ? AND status = 1 AND stock >= ?
      `).bind(item.quantity, item.product_id, item.quantity)
    );
  }

  try {
    const results = await env.DB.batch(statements);

    // The first result is the INSERT; every following result must change one row.
    for (let i = 1; i < results.length; i++) {
      if (Number(results[i]?.meta?.changes || 0) !== 1) {
        throw new Error("Stock changed before checkout completed. Please try again.");
      }
    }

    const order = results[0]?.results?.[0] || null;
    if (!order) throw new Error("Order was not returned after creation.");

    return json({
      success: true,
      message: "Order created successfully",
      order,
      price_verified: true,
      stock_updated: true,
      client_amount: Number(clientAmount.toFixed(2)),
      server_amount: calculated.total,
      notify: {
        success: true,
        status: "pending_integration",
        delivery_track_id: deliveryTrackId
      }
    });
  } catch (error) {
    console.error("Create order database/stock transaction error:", error);
    return json({
      success: false,
      message: "Unable to place order",
      detail: error.message || "Database transaction failed"
    }, 500);
  }
}

async function getProducts(env) {
  try {
    const result = await env.DB.prepare(`
      SELECT rowid, name, description, images, price, discount,
             category_id, category_name, category_img,
             featured, featured_img, stock
      FROM mr_hawker_test
      WHERE status = 1
      ORDER BY rowid DESC
    `).all();

    return json({ success: true, products: result.results || [] });
  } catch (error) {
    console.error("Database error:", error);
    return json({ success: false, message: "Unable to load products" }, 500);
  }
}

async function trackOrder(request, env) {
  const url = new URL(request.url);
  const trackId = String(url.searchParams.get("delivery_track_id") || url.searchParams.get("id") || "").trim();

  if (!/^\d{12}$/.test(trackId)) {
    return json({ success: false, message: "Delivery track ID must be exactly 12 digits" }, 400);
  }

  try {
    await ensureOrderTrackingSchema(env.DB);

    const order = await env.DB.prepare(`
      SELECT rowid, delivery_track_id, order_date, delivery_date,
             delivery_status, delivery_data, payment_status, amount
      FROM mr_hawker_orders
      WHERE delivery_track_id = ? LIMIT 1
    `).bind(trackId).first();

    if (!order) return json({ success: false, message: "Tracking ID not found" }, 404);

    const legacyStatusData = parseDeliveryStatus(order.delivery_status);
    const status = statusName(order.delivery_status);
    let deliveryData = parseDeliveryData(order.delivery_data);

    // Backward compatibility for older rows where the JSON was incorrectly
    // stored inside delivery_status. New rows always use delivery_data.
    if (!Object.keys(deliveryData).length && (status === "rejected" || status === "shipped_to_rider")) {
      const legacy = { ...legacyStatusData };
      delete legacy.status;
      deliveryData = legacy;
    }

    return json({
      success: true,
      order: {
        ...order,
        delivery_status: status,
        delivery_data: Object.keys(deliveryData).length ? deliveryData : null,
        // Keep this response property for compatibility with the current track UI.
        delivery_status_data: Object.keys(deliveryData).length ? deliveryData : {}
      }
    });
  } catch (error) {
    console.error("Tracking error:", error);
    return json({ success: false, message: "Unable to load tracking information" }, 500);
  }
}

async function notifyOrder(request, env) {
  try {
    const data = await request.json();
    const trackId = String(data.delivery_track_id || "").trim();

    if (!/^\d{12}$/.test(trackId)) {
      return json({ success: false, message: "Invalid delivery track ID" }, 400);
    }

    const order = await env.DB.prepare(`
      SELECT rowid, delivery_track_id FROM mr_hawker_orders
      WHERE delivery_track_id = ? LIMIT 1
    `).bind(trackId).first();

    if (!order) return json({ success: false, message: "Order not found" }, 404);

    return json({
      success: true,
      message: "Notification accepted",
      delivery_track_id: trackId,
      email: { status: "pending_integration" },
      fcm: { status: "pending_integration" }
    });
  } catch (error) {
    console.error("Notify error:", error);
    return json({ success: false, message: "Unable to process notification" }, 500);
  }
}

async function adminProducts(request, env) {
  const url = new URL(request.url);

  try {
    if (request.method === "POST") {
      const data = await request.json();
      const result = await env.DB.prepare(`
        INSERT INTO mr_hawker_test (
          name, description, images, price, discount,
          category_id, category_name, category_img,
          featured, featured_img, stock, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        RETURNING rowid, *
      `).bind(
        data.name, data.description ?? null, data.images ?? null,
        data.price, data.discount ?? 0, data.category_id ?? null,
        data.category_name ?? null, data.category_img ?? null,
        data.featured ?? 0, data.featured_img ?? null,
        data.stock ?? 0, data.status ?? 1
      ).first();

      return json({ success: true, message: "Product added successfully", product: result });
    }

    if (request.method === "PUT") {
      const data = await request.json();
      if (!data.id) return json({ success: false, message: "Product ID is required" }, 400);

      const allowedFields = [
        "name","description","images","price","discount","category_id",
        "category_name","category_img","featured","featured_img","stock","status"
      ];
      const fields = [], values = [];
      for (const field of allowedFields) {
        if (Object.prototype.hasOwnProperty.call(data, field)) {
          fields.push(`${field} = ?`);
          values.push(data[field]);
        }
      }
      if (!fields.length) return json({ success: false, message: "No fields to update" }, 400);

      values.push(data.id);
      const result = await env.DB.prepare(`
        UPDATE mr_hawker_test SET ${fields.join(", ")}
        WHERE rowid = ? RETURNING rowid, *
      `).bind(...values).first();

      if (!result) return json({ success: false, message: "Product not found" }, 404);
      return json({ success: true, message: "Product updated successfully", product: result });
    }

    if (request.method === "DELETE") {
      const data = await request.json();
      if (!data.id) return json({ success: false, message: "Product ID is required" }, 400);

      const result = await env.DB.prepare(`
        DELETE FROM mr_hawker_test WHERE rowid = ? RETURNING rowid, *
      `).bind(data.id).first();

      if (!result) return json({ success: false, message: "Product not found" }, 404);
      return json({ success: true, message: "Product deleted successfully", product: result });
    }

    return json({ success: false, message: "Method not allowed" }, 405);
  } catch (error) {
    console.error("Admin product error:", error);
    return json({ success: false, message: "Unable to modify product", detail: error.message }, 500);
  }
}

async function restoreOrderStock(env, order) {
  let items;
  try {
    items = typeof order.orders === "string" ? JSON.parse(order.orders) : order.orders;
  } catch {
    return [];
  }
  if (!Array.isArray(items)) return [];

  const statements = [];
  for (const item of items) {
    const id = Number(item?.product_id ?? item?.id);
    const qty = Number(item?.quantity);
    if (Number.isInteger(id) && id > 0 && Number.isInteger(qty) && qty > 0) {
      statements.push(env.DB.prepare(`
        UPDATE mr_hawker_test SET stock = stock + ? WHERE rowid = ?
      `).bind(qty, id));
    }
  }
  if (statements.length) await env.DB.batch(statements);
  return items;
}

async function adminOrders(request, env) {
  const url = new URL(request.url);

  try {
    if (request.method === "GET") {
      const orderId = url.searchParams.get("id");
      if (orderId) {
        const order = await env.DB.prepare(`SELECT * FROM mr_hawker_orders WHERE rowid = ?`).bind(orderId).first();
        if (!order) return json({ success: false, message: "Order not found" }, 404);
        return json({ success: true, order });
      }

      const result = await env.DB.prepare(`SELECT * FROM mr_hawker_orders ORDER BY rowid DESC`).all();
      return json({ success: true, orders: result.results || [] });
    }

    if (request.method === "PUT") {
      const data = await request.json();
      if (!data.rowid) return json({ success: false, message: "Order rowid is required" }, 400);

      const existing = await env.DB.prepare(`SELECT * FROM mr_hawker_orders WHERE rowid = ?`).bind(data.rowid).first();
      if (!existing) return json({ success: false, message: "Order not found" }, 404);

      const allowedFields = [
        "name","phone","email","address","orders","order_date","delivery_date",
        "delivery_status","delivery_data","amount","payment_type","payment_status","trx_id","delivery_track_id"
      ];
      const fields = [], values = [];

      for (const field of allowedFields) {
        if (Object.prototype.hasOwnProperty.call(data, field)) {
          let value = data[field];

          if (field === "delivery_status") {
            const parsed = parseDeliveryStatus(value);
            const normalized = String(parsed.status || "pending").toLowerCase().trim();
            const allowed = ["pending","packaging","ready_to_shipping","shipped_to_rider","completed","rejected"];
            if (!allowed.includes(normalized)) {
              return json({ success: false, message: "Invalid delivery status" }, 400);
            }
            // delivery_status is always a plain status now. JSON details belong
            // in the dedicated delivery_data column.
            value = normalized;

            // If an older admin client sends {status, ...details} in the
            // delivery_status field, migrate those details automatically.
            if (["rejected", "shipped_to_rider"].includes(normalized)) {
              const legacyDetails = { ...parsed };
              delete legacyDetails.status;
              if (Object.keys(legacyDetails).length && !Object.prototype.hasOwnProperty.call(data, "delivery_data")) {
                fields.push("delivery_data = ?");
                values.push(JSON.stringify(legacyDetails));
              }
            }
          }

          if (field === "delivery_data") {
            const statusForData = Object.prototype.hasOwnProperty.call(data, "delivery_status")
              ? statusName(data.delivery_status)
              : statusName(existing.delivery_status);
            if (!["rejected", "shipped_to_rider"].includes(statusForData)) {
              value = "NULL";
            } else {
              value = normalizeDeliveryData(value);
            }
          }

          if (field === "payment_status") {
            value = String(value).toLowerCase();
            if (!["pending","paid","rejected","failed"].includes(value)) {
              return json({ success: false, message: "Invalid payment status" }, 400);
            }
          }

          fields.push(`${field} = ?`);
          values.push(value);
        }
      }

      if (!fields.length) return json({ success: false, message: "No fields to update" }, 400);

      const newDeliveryStatus = Object.prototype.hasOwnProperty.call(data, "delivery_status")
        ? statusName(data.delivery_status)
        : statusName(existing.delivery_status);

      // Details are meaningful only for rejected and shipped_to_rider.
      // If the admin moves the order to another status without sending
      // delivery_data, clear any old rider/rejection JSON.
      if (Object.prototype.hasOwnProperty.call(data, "delivery_status") &&
          !["rejected", "shipped_to_rider"].includes(newDeliveryStatus) &&
          !Object.prototype.hasOwnProperty.call(data, "delivery_data")) {
        fields.push("delivery_data = ?");
        values.push("NULL");
      }

      const wasRejected = statusName(existing.delivery_status) === "rejected";
      const willBeRejected = newDeliveryStatus === "rejected";

      /*
       * When an admin rejects an order/payment, return its reserved stock.
       * We only restore it on the first transition into rejected, preventing
       * repeated admin edits from adding the same stock multiple times.
       */
      let stockStatements = [];
      if (willBeRejected && !wasRejected) {
        let items;
        try {
          items = typeof existing.orders === "string" ? JSON.parse(existing.orders) : existing.orders;
        } catch { items = []; }

        if (Array.isArray(items)) {
          for (const item of items) {
            const id = Number(item?.product_id ?? item?.id);
            const qty = Number(item?.quantity);
            if (Number.isInteger(id) && id > 0 && Number.isInteger(qty) && qty > 0) {
              stockStatements.push(env.DB.prepare(`
                UPDATE mr_hawker_test SET stock = stock + ? WHERE rowid = ?
              `).bind(qty, id));
            }
          }
        }
      }

      values.push(data.rowid);

      const updateStatement = env.DB.prepare(`
        UPDATE mr_hawker_orders SET ${fields.join(", ")}
        WHERE rowid = ? RETURNING rowid, *
      `).bind(...values);

      const results = await env.DB.batch([...stockStatements, updateStatement]);
      const order = results[results.length - 1]?.results?.[0] || null;

      return json({
        success: true,
        message: "Order updated successfully",
        order,
        stock_restored: willBeRejected && !wasRejected
      });
    }

    if (request.method === "DELETE") {
      const data = await request.json();
      if (!data.rowid) return json({ success: false, message: "Order rowid is required" }, 400);

      const result = await env.DB.prepare(`
        DELETE FROM mr_hawker_orders WHERE rowid = ? RETURNING rowid, *
      `).bind(data.rowid).first();

      if (!result) return json({ success: false, message: "Order not found" }, 404);
      return json({ success: true, message: "Order deleted successfully", order: result });
    }

    return json({ success: false, message: "Method not allowed" }, 405);
  } catch (error) {
    console.error("Admin order error:", error);
    return json({ success: false, message: "Unable to modify order", detail: error.message }, 500);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/products" && request.method === "GET") {
      return getProducts(env);
    }

    if (url.pathname === "/api/orders" && request.method === "POST") {
      return createOrder(request, env);
    }

    if (url.pathname === "/api/track" && request.method === "GET") {
      return trackOrder(request, env);
    }

    if (url.pathname === "/api/notify" && request.method === "POST") {
      return notifyOrder(request, env);
    }

    /*
     * Everything under /api/admin/ is protected by the Cloudflare Worker
     * secret INTERNAL_API_SECRET. Never expose this secret in the website.
     */
    if (url.pathname.startsWith("/api/admin/")) {
      const apiKey = request.headers.get("X-API-Key");
      if (!apiKey || apiKey !== env.INTERNAL_API_SECRET) {
        return json({ success: false, message: "Unauthorized" }, 401);
      }

      if (url.pathname === "/api/admin/products") return adminProducts(request, env);
      if (url.pathname === "/api/admin/orders") return adminOrders(request, env);
    }

    return env.ASSETS.fetch(request);
  }
};
